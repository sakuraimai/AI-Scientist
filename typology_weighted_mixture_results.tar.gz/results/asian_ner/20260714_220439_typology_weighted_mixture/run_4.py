"""
asian_ner — AI Scientist v1 template (minimal PoC)

Compares six multilingual NER training regimes on WikiAnn:
  1. linguistic_clustering       — Head-parameter grouping (ACL 2023 lineage)
  2. embedding_clustering        — XLM-R [CLS] embeddings + agglomerative clustering
  3. per_language                — monolingual baseline (Mongolian only for mn metric)
  4. all_mixed                   — train on all languages jointly (full cap=0 pool; ceiling)
  5. matched_random_embedding    — N_ref = embedding target cluster; random pool sample
  6. matched_random_linguistic   — N_ref = linguistic target cluster; random pool sample

Primary metrics: low_resource_macro_f1 and average_f1 (pool-wide); mongolian_f1 illustrative.

Default protocol: cap=0; matched controls sample to each clustering target cluster n;
all_mixed uses the full pool (no downsample).

Usage:
  python experiment.py --out_dir run_0
  python experiment.py --out_dir run_0 --quick   # fewer steps for smoke test

Dependencies (AI-Scientist venv):
  torch, transformers, datasets, sklearn, seqeval, numpy, accelerate
"""

from __future__ import annotations

import argparse
import json
import math
import os
import random
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
from datasets import Dataset, concatenate_datasets, load_dataset
from sklearn.cluster import AgglomerativeClustering
from sklearn.metrics import pairwise_distances, silhouette_score
from transformers import (
    AutoModelForSequenceClassification,
    AutoModelForTokenClassification,
    AutoTokenizer,
    DataCollatorForTokenClassification,
    Trainer,
    TrainingArguments,
)

try:
    from seqeval.metrics import f1_score as seqeval_f1
except ImportError:  # pragma: no cover
    seqeval_f1 = None

from language_pool import resolve_experiment_languages

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

MODEL_NAME = "xlm-roberta-base"

_POOL_META = resolve_experiment_languages()
LANGUAGES: List[str] = _POOL_META["languages"]
LANG_TRAIN_COUNTS: Dict[str, int] = _POOL_META["train_counts"]
LOW_RESOURCE_LANGS: List[str] = _POOL_META["low_resource_langs"]
LOW_RESOURCE_THRESHOLD: int = _POOL_META["low_resource_threshold"]

TARGET_LANG = "mn"
PRIMARY_METRIC_KEY = "mongolian_f1"
LOW_RESOURCE_METRIC_KEY = "low_resource_macro_f1"

HEAD_FINAL = {"ja", "ko", "mn"}
HEAD_INITIAL = {"ru"}

LABEL_LIST = ["O", "B-PER", "I-PER", "B-ORG", "I-ORG", "B-LOC", "I-LOC"]
LABEL2ID = {label: i for i, label in enumerate(LABEL_LIST)}
ID2LABEL = {i: label for label, i in LABEL2ID.items()}

NER_TAGS = ["O", "B-PER", "I-PER", "B-ORG", "I-ORG", "B-LOC", "I-LOC"]

CONDITIONS = [
    "linguistic_clustering",
    "embedding_clustering",
    "per_language",
    "all_mixed",
    "matched_random_embedding",
    "matched_random_linguistic",
]

MATCHED_RANDOM_SEED_OFFSETS = {
    "matched_random_embedding": 4242,
    "matched_random_linguistic": 4343,
}
UPSAMPLE_EXCLUDE_CONDITIONS = {"per_language", "all_mixed"}
UPSAMPLE_SEED_OFFSETS = {
    "linguistic_clustering": 1000,
    "embedding_clustering": 2000,
    "matched_random_embedding": 3000,
    "matched_random_linguistic": 3100,
}
DOWNSAMPLE_SEED_OFFSETS = {
    "all_mixed": 4000,
    "matched_random_embedding": 5000,
    "matched_random_linguistic": 5100,
}


@dataclass
class RunConfig:
    out_dir: str
    seed: int
    max_epochs: int
    batch_size: int
    learning_rate: float
    max_length: int
    max_train_per_lang: int
    max_embed_samples_per_lang: int
    max_eval_samples_per_lang: int
    lang_id_epochs: int
    n_clusters: int
    quick: bool
    upsample_to: Optional[str] = None
    downsample_to: Optional[str] = None
    budget_n_ref: Optional[int] = None
    budget_n_ref_embedding: Optional[int] = None
    budget_n_ref_linguistic: Optional[int] = None
    downsample_conditions: Optional[set] = None
    skip_conditions: Optional[set] = None


def build_config(args: argparse.Namespace) -> RunConfig:
    quick = args.quick
    downsample_to = None
    if not quick and args.downsample_to and args.downsample_to != "none":
        downsample_to = args.downsample_to
    return RunConfig(
        out_dir=args.out_dir,
        seed=args.seed,
        max_epochs=1 if quick else args.max_epochs,
        batch_size=8 if quick else args.batch_size,
        learning_rate=args.learning_rate,
        max_length=96 if quick else args.max_length,
        max_train_per_lang=50 if quick else args.max_train_per_lang,
        max_embed_samples_per_lang=50 if quick else args.max_embed_samples_per_lang,
        max_eval_samples_per_lang=50 if quick else 0,
        lang_id_epochs=1,
        n_clusters=2,
        quick=quick,
        upsample_to=args.upsample_to,
        downsample_to=downsample_to,
        skip_conditions=getattr(args, "skip_conditions_set", None),
    )


def get_device() -> torch.device:
    if torch.cuda.is_available():
        return torch.device("cuda")
    # Skip MPS: token-classification eval hits position_ids bugs on Apple Silicon.
    return torch.device("cpu")


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


# ---------------------------------------------------------------------------
# Data
# ---------------------------------------------------------------------------


WIKIANN_DATASET = "unimelb-nlp/wikiann"


def load_wikiann_split(lang: str, split: str) -> Dataset:
    import datasets as _datasets

    major = int(_datasets.__version__.split(".")[0])
    kwargs = {"trust_remote_code": True} if major < 3 else {}
    ds = load_dataset(WIKIANN_DATASET, lang, split=split, **kwargs)
    return ds


def cap_dataset(ds: Dataset, max_samples: int) -> Dataset:
    if max_samples <= 0 or len(ds) <= max_samples:
        return ds
    return ds.select(range(max_samples))


def tokenize_and_align(
    examples: Dict,
    tokenizer,
    max_length: int,
) -> Dict:
    tokenized = tokenizer(
        examples["tokens"],
        truncation=True,
        is_split_into_words=True,
        max_length=max_length,
    )
    labels = []
    for i, tag_row in enumerate(examples["ner_tags"]):
        word_ids = tokenized.word_ids(batch_index=i)
        label_ids = []
        prev_word = None
        for word_id in word_ids:
            if word_id is None:
                label_ids.append(-100)
            elif word_id != prev_word:
                label_ids.append(int(tag_row[word_id]))
            else:
                label_ids.append(-100)
            prev_word = word_id
        labels.append(label_ids)
    tokenized["labels"] = labels
    return tokenized


def prepare_ner_dataset(
    langs: List[str],
    split: str,
    tokenizer,
    cfg: RunConfig,
) -> Dataset:
    raw = load_raw_ner_dataset(langs, split, cfg)
    return tokenize_ner_dataset(raw, tokenizer, cfg.max_length)


def load_raw_ner_dataset(
    langs: List[str],
    split: str,
    cfg: RunConfig,
) -> Dataset:
    parts = []
    for lang in langs:
        ds = load_wikiann_split(lang, split)
        if split == "train":
            ds = cap_dataset(ds, cfg.max_train_per_lang)
        parts.append(ds)
    return parts[0] if len(parts) == 1 else concatenate_datasets(parts)


def tokenize_ner_dataset(raw_ds: Dataset, tokenizer, max_length: int) -> Dataset:
    return raw_ds.map(
        lambda x: tokenize_and_align(x, tokenizer, max_length),
        batched=True,
        remove_columns=raw_ds.column_names,
    )


def build_train_pool(cfg: RunConfig) -> Dataset:
    """All training sentences from the fixed language pool (respecting per-lang cap)."""
    return load_raw_ner_dataset(LANGUAGES, "train", cfg)


def effective_train_count(lang: str, cfg: RunConfig) -> int:
    """WikiAnn train count after per-language cap (0 = no cap)."""
    raw = LANG_TRAIN_COUNTS[lang]
    if cfg.max_train_per_lang <= 0:
        return raw
    return min(raw, cfg.max_train_per_lang)


def count_train_samples(train_langs: List[str], cfg: RunConfig) -> int:
    return sum(effective_train_count(lang, cfg) for lang in train_langs)


def cluster_langs_by_id(cluster_map: Dict[str, int]) -> Dict[int, List[str]]:
    clusters: Dict[int, List[str]] = {}
    for lang, cid in cluster_map.items():
        clusters.setdefault(cid, []).append(lang)
    return clusters


def cluster_sample_counts(
    cluster_map: Dict[str, int],
    cfg: RunConfig,
) -> Dict[int, Dict]:
    """Per-cluster train budget metadata using effective per-language caps."""
    out: Dict[int, Dict] = {}
    for cid, langs in sorted(cluster_langs_by_id(cluster_map).items()):
        sorted_langs = sorted(langs)
        out[cid] = {
            "langs": sorted_langs,
            "n_samples": count_train_samples(sorted_langs, cfg),
        }
    return out


def largest_cluster_n_ref(
    cluster_maps: List[Dict[str, int]],
    cfg: RunConfig,
) -> Tuple[int, Dict[str, Dict[int, Dict]]]:
    """N_ref = max train samples among clusters across the given partitions."""
    per_map: Dict[str, Dict[int, Dict]] = {}
    max_n = 0
    for i, cluster_map in enumerate(cluster_maps):
        counts = cluster_sample_counts(cluster_map, cfg)
        key = "embedding" if i == 0 else "linguistic" if i == 1 else f"map_{i}"
        per_map[key] = counts
        if counts:
            max_n = max(max_n, max(v["n_samples"] for v in counts.values()))
    return max_n, per_map


def resolve_training_budget(
    cfg: RunConfig,
    emb_map: Dict[str, int],
    ling_map: Dict[str, int],
    emb_train_langs: List[str],
    ling_train_langs: List[str],
) -> Dict:
    """Resolve per-condition train budgets; return budget metadata."""
    emb_n = count_train_samples(emb_train_langs, cfg)
    ling_n = count_train_samples(ling_train_langs, cfg)
    pool_n = count_train_samples(LANGUAGES, cfg)
    cfg.budget_n_ref_embedding = emb_n
    cfg.budget_n_ref_linguistic = ling_n

    meta: Dict = {
        "target_lang": TARGET_LANG,
        "embedding_train_langs": sorted(emb_train_langs),
        "linguistic_train_langs": sorted(ling_train_langs),
        "embedding_cluster_n_samples": emb_n,
        "linguistic_cluster_n_samples": ling_n,
        "all_mixed_n_samples": pool_n,
        "matched_random_embedding_n": emb_n,
        "matched_random_linguistic_n": ling_n,
    }

    if cfg.downsample_to == "largest_cluster":
        n_ref, cluster_sizes = largest_cluster_n_ref([emb_map, ling_map], cfg)
        cfg.budget_n_ref = n_ref
        cfg.downsample_conditions = {
            "all_mixed",
            "matched_random_embedding",
            "matched_random_linguistic",
        }
        meta.update(
            {
                "mode": "largest_cluster_downsample",
                "n_ref": n_ref,
                "cluster_sizes": cluster_sizes,
                "downsample_conditions": sorted(cfg.downsample_conditions),
            }
        )
        meta["matched_random_embedding_n"] = n_ref
        meta["matched_random_linguistic_n"] = n_ref
        cfg.budget_n_ref_embedding = n_ref
        cfg.budget_n_ref_linguistic = n_ref
        print(
            f"[budget] largest_cluster legacy N_ref={n_ref} "
            f"(downsample {sorted(cfg.downsample_conditions)})"
        )
        return meta

    # Default (target_cluster): dual matched controls; all_mixed full pool.
    cfg.budget_n_ref = None
    cfg.downsample_conditions = set()
    meta.update(
        {
            "mode": "target_cluster_matched_controls",
            "downsample_conditions": [],
        }
    )
    print(
        f"[budget] target_cluster matched: embedding N={emb_n} "
        f"(langs={sorted(emb_train_langs)}), linguistic N={ling_n} "
        f"(langs={sorted(ling_train_langs)}); all_mixed N={pool_n} (full pool)"
    )
    return meta


def sample_matched_random_pool(
    pool: Dataset,
    n_samples: int,
    seed: int,
) -> Tuple[Dataset, List[int]]:
    n_samples = min(n_samples, len(pool))
    rng = np.random.RandomState(seed)
    indices = rng.choice(len(pool), size=n_samples, replace=False).tolist()
    return pool.select(indices), indices


def get_upsample_target_n(cfg: RunConfig) -> Optional[int]:
    if not cfg.upsample_to:
        return None
    if cfg.upsample_to == "all_mixed":
        return len(build_train_pool(cfg))
    raise ValueError(f"Unknown upsample_to reference: {cfg.upsample_to}")


def upsample_seed_for_condition(cfg: RunConfig, condition_name: str) -> int:
    return cfg.seed + UPSAMPLE_SEED_OFFSETS.get(condition_name, 9000)


def downsample_raw_dataset(
    raw_ds: Dataset,
    target_n: int,
    seed: int,
) -> Tuple[Dataset, Dict]:
    n_unique = len(raw_ds)
    if n_unique <= target_n:
        return raw_ds, {
            "downsampled": False,
            "n_unique_train_samples": n_unique,
            "n_train_samples": n_unique,
            "downsample_target_n": target_n,
        }
    rng = np.random.RandomState(seed)
    indices = rng.choice(n_unique, size=target_n, replace=False).tolist()
    return raw_ds.select(indices), {
        "downsampled": True,
        "n_unique_train_samples": n_unique,
        "n_train_samples": target_n,
        "downsample_target_n": target_n,
        "downsample_seed": seed,
        "downsample_without_replacement": True,
    }


def upsample_raw_dataset(
    raw_ds: Dataset,
    target_n: int,
    seed: int,
) -> Tuple[Dataset, Dict]:
    n_unique = len(raw_ds)
    if n_unique >= target_n:
        return raw_ds, {
            "upsampled": False,
            "n_unique_train_samples": n_unique,
            "n_train_samples": n_unique,
            "upsample_target_n": target_n,
        }
    rng = np.random.RandomState(seed)
    indices = rng.choice(n_unique, size=target_n, replace=True).tolist()
    return raw_ds.select(indices), {
        "upsampled": True,
        "n_unique_train_samples": n_unique,
        "n_train_samples": target_n,
        "upsample_target_n": target_n,
        "upsample_seed": seed,
        "upsample_with_replacement": True,
    }


def compute_training_schedule(
    n_train_samples: int,
    batch_size: int,
    num_epochs: int,
) -> Dict:
    """Estimate HF Trainer steps: ceil(n / batch_size) per epoch."""
    steps_per_epoch = max(1, math.ceil(n_train_samples / batch_size))
    total_steps = steps_per_epoch * num_epochs
    samples_per_epoch = n_train_samples
    total_sample_updates = samples_per_epoch * num_epochs
    return {
        "steps_per_epoch": steps_per_epoch,
        "total_steps": total_steps,
        "samples_per_epoch": samples_per_epoch,
        "total_sample_updates": total_sample_updates,
        "per_device_train_batch_size": batch_size,
        "num_train_epochs": num_epochs,
    }


def apply_training_budget(
    raw_ds: Dataset,
    cfg: RunConfig,
    condition_name: str,
) -> Tuple[Dataset, Dict]:
    meta: Dict = {
        "condition": condition_name,
        "n_unique_train_samples": len(raw_ds),
        "n_train_samples": len(raw_ds),
        "upsampled": False,
        "downsampled": False,
        "upsample_to": cfg.upsample_to,
        "downsample_to": cfg.downsample_to,
        "budget_n_ref": cfg.budget_n_ref,
    }
    if (
        cfg.budget_n_ref is not None
        and cfg.downsample_conditions
        and condition_name in cfg.downsample_conditions
        and len(raw_ds) > cfg.budget_n_ref
    ):
        raw_ds, down_meta = downsample_raw_dataset(
            raw_ds,
            target_n=cfg.budget_n_ref,
            seed=cfg.seed + DOWNSAMPLE_SEED_OFFSETS.get(condition_name, 4500),
        )
        meta.update(down_meta)
    target_n = get_upsample_target_n(cfg)
    if (
        target_n is not None
        and condition_name not in UPSAMPLE_EXCLUDE_CONDITIONS
        and len(raw_ds) < target_n
    ):
        raw_ds, up_meta = upsample_raw_dataset(
            raw_ds,
            target_n=target_n,
            seed=upsample_seed_for_condition(cfg, condition_name),
        )
        meta.update(up_meta)
    schedule = compute_training_schedule(len(raw_ds), cfg.batch_size, cfg.max_epochs)
    meta.update(schedule)
    suffix = ""
    if meta.get("downsampled"):
        suffix = " (downsampled)"
    elif meta.get("upsampled"):
        suffix = " (upsampled)"
    print(
        f"[{condition_name}] train_budget: "
        f"unique={meta['n_unique_train_samples']} "
        f"train_n={meta['n_train_samples']} "
        f"steps/epoch={schedule['steps_per_epoch']} "
        f"total_steps={schedule['total_steps']} "
        f"epochs={cfg.max_epochs} batch={cfg.batch_size}"
        f"{suffix}"
    )
    return raw_ds, meta


# ---------------------------------------------------------------------------
# Clustering  (EVOLVE-BLOCK — AI Scientist may modify these functions)
# Also modifiable: post_cluster_train_langs(), augment_train_raw()
# ---------------------------------------------------------------------------

# run_1 hypothesis: typology soft-constraint on embedding distances + silhouette k.
HYBRID_TYPOLOGY_PENALTY = 1.0


def cluster_linguistic(langs: List[str]) -> Dict[str, int]:
    """Head-parameter rule-based clustering."""
    mapping: Dict[str, int] = {}
    for lang in langs:
        if lang in HEAD_FINAL:
            mapping[lang] = 0
        elif lang in HEAD_INITIAL:
            mapping[lang] = 1
        else:
            mapping[lang] = 1
    return mapping


def _sentence_cls_embeddings(
    langs: List[str],
    cfg: RunConfig,
    device: torch.device,
) -> Tuple[Dict[str, np.ndarray], AutoTokenizer]:
    """Language-ID fine-tuned XLM-R [CLS] embeddings per language (mean-pooled)."""
    tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
    model = AutoModelForSequenceClassification.from_pretrained(
        MODEL_NAME,
        num_labels=len(langs),
        id2label={i: l for i, l in enumerate(langs)},
        label2id={l: i for i, l in enumerate(langs)},
    ).to(device)

    train_texts: List[str] = []
    train_labels: List[int] = []
    lang2id = {l: i for i, l in enumerate(langs)}
    for lang in langs:
        ds = cap_dataset(load_wikiann_split(lang, "validation"), cfg.max_embed_samples_per_lang)
        for row in ds:
            train_texts.append(" ".join(row["tokens"]))
            train_labels.append(lang2id[lang])

    enc = tokenizer(
        train_texts,
        truncation=True,
        padding=True,
        max_length=cfg.max_length,
        return_tensors="pt",
    )
    enc = {k: v.to(device) for k, v in enc.items()}
    labels_t = torch.tensor(train_labels, device=device)

    optim = torch.optim.AdamW(model.parameters(), lr=cfg.learning_rate)
    model.train()
    bs = min(cfg.batch_size, len(train_texts))
    for _ in range(cfg.lang_id_epochs):
        perm = torch.randperm(len(train_texts))
        for start in range(0, len(train_texts), bs):
            idx = perm[start : start + bs]
            batch = {k: v[idx] for k, v in enc.items()}
            y = labels_t[idx]
            out = model(**batch, labels=y)
            loss = out.loss
            loss.backward()
            optim.step()
            optim.zero_grad()

    model.eval()
    lang_embeddings: Dict[str, List[np.ndarray]] = {l: [] for l in langs}
    with torch.no_grad():
        for lang in langs:
            ds = cap_dataset(load_wikiann_split(lang, "validation"), cfg.max_embed_samples_per_lang)
            for row in ds:
                inputs = tokenizer(
                    " ".join(row["tokens"]),
                    truncation=True,
                    max_length=cfg.max_length,
                    return_tensors="pt",
                ).to(device)
                hidden = model.base_model(**inputs).last_hidden_state[:, 0, :].cpu().numpy()[0]
                lang_embeddings[lang].append(hidden)

    pooled = {lang: np.mean(v, axis=0) for lang, v in lang_embeddings.items()}
    return pooled, tokenizer


def _typology_id(lang: str) -> int:
    return 0 if lang in HEAD_FINAL else 1


def _hybrid_lang_distance_matrix(
    langs: List[str],
    embeddings: np.ndarray,
    penalty_weight: float,
) -> np.ndarray:
    """Euclidean embedding distance + penalty when typology groups differ."""
    dist = pairwise_distances(embeddings, metric="euclidean")
    scale = float(dist[np.triu_indices_from(dist, k=1)].mean()) if len(langs) > 1 else 1.0
    hybrid = dist.copy()
    for i in range(len(langs)):
        for j in range(i + 1, len(langs)):
            if _typology_id(langs[i]) != _typology_id(langs[j]):
                hybrid[i, j] += penalty_weight * scale
                hybrid[j, i] = hybrid[i, j]
    return hybrid


def _select_k_by_silhouette(
    dist: np.ndarray,
    fallback_k: int,
    min_k: int = 2,
    max_k: int = 4,
) -> Tuple[int, float]:
    n = dist.shape[0]
    max_k = min(max_k, n - 1)
    best_k, best_score = fallback_k, -1.0
    for k in range(min_k, max_k + 1):
        labels = AgglomerativeClustering(
            n_clusters=k,
            metric="precomputed",
            linkage="average",
        ).fit_predict(dist)
        if len(set(labels)) < 2:
            continue
        score = float(silhouette_score(dist, labels, metric="precomputed"))
        if score > best_score:
            best_score = score
            best_k = k
    return best_k, best_score


def cluster_embedding(
    langs: List[str],
    cfg: RunConfig,
    device: torch.device,
) -> Tuple[Dict[str, int], Dict]:
    """Hybrid typology-embedding clustering (run_1): penalize cross-typology pairs, silhouette k."""
    pooled, _ = _sentence_cls_embeddings(langs, cfg, device)
    keys = list(langs)
    matrix = np.stack([pooled[k] for k in keys], axis=0)
    hybrid_dist = _hybrid_lang_distance_matrix(
        keys, matrix, penalty_weight=HYBRID_TYPOLOGY_PENALTY
    )
    n_clusters, sil_score = _select_k_by_silhouette(
        hybrid_dist, fallback_k=cfg.n_clusters, max_k=min(4, len(keys) - 1)
    )
    labels = AgglomerativeClustering(
        n_clusters=n_clusters,
        metric="precomputed",
        linkage="average",
    ).fit_predict(hybrid_dist)
    cluster_map = {lang: int(label) for lang, label in zip(keys, labels)}
    meta = {
        "method": "hybrid_typology_embedding",
        "n_clusters": n_clusters,
        "n_clusters_selection": "silhouette",
        "silhouette_score": sil_score,
        "linkage": "average",
        "distance_metric": "euclidean_embedding_plus_typology_penalty",
        "typology_penalty_weight": HYBRID_TYPOLOGY_PENALTY,
        "embedding_source": "xlm-roberta-base_lang_id_cls",
        "cluster_map": cluster_map,
    }
    return cluster_map, meta


def langs_in_cluster(target: str, cluster_map: Dict[str, int]) -> List[str]:
    cid = cluster_map[target]
    return [l for l, c in cluster_map.items() if c == cid]


def post_cluster_train_langs(
    target: str,
    train_langs: List[str],
    cluster_map: Dict[str, int],
    cfg: RunConfig,
    source: str,
) -> List[str]:
    """EVOLVE-BLOCK: fallback or augment language set after clustering."""
    return train_langs


def augment_train_raw(
    raw_ds: Dataset,
    train_langs: List[str],
    cfg: RunConfig,
    condition_name: str,
) -> Dataset:
    """EVOLVE-BLOCK: mn oversample, language reweighting, etc."""
    return raw_ds


# ---------------------------------------------------------------------------
# NER train / eval
# ---------------------------------------------------------------------------


def train_and_evaluate_ner(
    train_langs: List[str],
    eval_langs: List[str],
    cfg: RunConfig,
    device: torch.device,
    save_dir: Optional[str] = None,
    train_ds: Optional[Dataset] = None,
) -> Tuple[Dict[str, float], Dict]:
    tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
    if train_ds is None:
        train_ds = prepare_ner_dataset(train_langs, "train", tokenizer, cfg)

    model = AutoModelForTokenClassification.from_pretrained(
        MODEL_NAME,
        num_labels=len(LABEL_LIST),
        id2label=ID2LABEL,
        label2id=LABEL2ID,
    ).to(device)

    args = TrainingArguments(
        output_dir=save_dir or os.path.join(cfg.out_dir, "_tmp_train"),
        num_train_epochs=cfg.max_epochs,
        per_device_train_batch_size=cfg.batch_size,
        learning_rate=cfg.learning_rate,
        logging_steps=50,
        save_strategy="no",
        report_to=[],
        seed=cfg.seed,
        use_cpu=device.type == "cpu",
        dataloader_num_workers=4 if device.type == "cuda" else 0,
        dataloader_pin_memory=device.type == "cuda",
    )
    collator = DataCollatorForTokenClassification(tokenizer)
    trainer_kwargs = dict(
        model=model,
        args=args,
        train_dataset=train_ds,
        data_collator=collator,
    )
    try:
        trainer = Trainer(**trainer_kwargs, processing_class=tokenizer)
    except TypeError:
        trainer = Trainer(**trainer_kwargs, tokenizer=tokenizer)
    trainer.train()
    model.to(device)

    train_meta = {
        "global_step": int(trainer.state.global_step),
        "n_train_samples": len(train_ds),
        **compute_training_schedule(len(train_ds), cfg.batch_size, cfg.max_epochs),
    }

    scores: Dict[str, float] = {}
    for lang in eval_langs:
        scores[lang] = evaluate_lang_f1(model, tokenizer, lang, cfg, device)
    scores[PRIMARY_METRIC_KEY] = scores.get(TARGET_LANG, 0.0)
    low_scores = [scores[lang] for lang in LOW_RESOURCE_LANGS if lang in scores]
    scores[LOW_RESOURCE_METRIC_KEY] = (
        float(np.mean(low_scores)) if low_scores else 0.0
    )
    scores["average_f1"] = float(np.mean([scores[l] for l in eval_langs if l in scores]))
    return scores, train_meta


def evaluate_lang_f1(
    model,
    tokenizer,
    lang: str,
    cfg: RunConfig,
    device: torch.device,
) -> float:
    if seqeval_f1 is None:
        raise ImportError("seqeval is required: pip install seqeval")

    test_ds = load_wikiann_split(lang, "test")
    test_ds = cap_dataset(test_ds, cfg.max_eval_samples_per_lang)
    model.eval()
    all_preds: List[List[str]] = []
    all_refs: List[List[str]] = []

    for row in test_ds:
        tokenized = tokenizer(
            row["tokens"],
            is_split_into_words=True,
            truncation=True,
            max_length=cfg.max_length,
            return_tensors="pt",
        )
        word_ids = tokenized.word_ids(batch_index=0)
        inputs = {k: v.to(device) for k, v in tokenized.items() if k != "offset_mapping"}
        with torch.no_grad():
            logits = model(**inputs).logits[0].cpu().numpy()
        pred_ids = logits.argmax(-1)
        preds, refs = [], []
        prev = None
        for idx, word_id in enumerate(word_ids):
            if word_id is None or word_id == prev:
                continue
            preds.append(ID2LABEL.get(int(pred_ids[idx]), "O"))
            refs.append(NER_TAGS[int(row["ner_tags"][word_id])])
            prev = word_id
        all_preds.append(preds)
        all_refs.append(refs)

    return float(seqeval_f1(all_refs, all_preds))


# ---------------------------------------------------------------------------
# Conditions
# ---------------------------------------------------------------------------


def run_condition(
    name: str,
    train_langs: List[str],
    eval_langs: List[str],
    cluster_map: Optional[Dict[str, int]],
    cfg: RunConfig,
    device: torch.device,
    train_ds: Optional[Dataset] = None,
    raw_train_ds: Optional[Dataset] = None,
    extra_meta: Optional[Dict] = None,
) -> Dict:
    subdir = os.path.join(cfg.out_dir, name)
    os.makedirs(subdir, exist_ok=True)
    budget_meta: Dict = {}
    if train_ds is None:
        raw_ds = raw_train_ds or load_raw_ner_dataset(train_langs, "train", cfg)
        raw_ds = augment_train_raw(raw_ds, train_langs, cfg, name)
        raw_ds, budget_meta = apply_training_budget(raw_ds, cfg, name)
        tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
        train_ds = tokenize_ner_dataset(raw_ds, tokenizer, cfg.max_length)
    scores, train_meta = train_and_evaluate_ner(
        train_langs=train_langs,
        eval_langs=eval_langs,
        cfg=cfg,
        device=device,
        save_dir=subdir,
        train_ds=train_ds,
    )
    result = {
        "means": scores,
        "train_langs": train_langs,
        "n_train_samples": train_meta["n_train_samples"],
        "cluster_map": cluster_map or {},
        "training_budget": {**budget_meta, **train_meta},
    }
    if extra_meta:
        result.update(extra_meta)
    return result

def typology_weighted_sampling(
    langs: List[str],
    cluster_map: Dict[str, int],
    cfg: RunConfig,
) -> List[str]:
    """Sample or weight training sentences proportional to typology similarity."""
    # Test a different typology-based weighting strategy
    cluster_sizes = cluster_sample_counts(cluster_map, cfg)
    weighted_langs = []
    for cid, meta in cluster_sizes.items():
        weight = meta["n_samples"] ** 0.25  # Different weight configuration
        weighted_langs.extend(meta["langs"] * int(weight))
    return weighted_langs


def run_matched_random_condition(
    condition_name: str,
    n_samples: int,
    eval_langs: List[str],
    cfg: RunConfig,
    device: torch.device,
    reference_condition: str,
) -> Dict:
    """Random N-sample control matched to a clustering condition's train budget."""
    pool = build_train_pool(cfg)
    seed_offset = MATCHED_RANDOM_SEED_OFFSETS[condition_name]
    subset, indices = sample_matched_random_pool(
        pool,
        n_samples=n_samples,
        seed=cfg.seed + seed_offset,
    )
    meta_path = os.path.join(cfg.out_dir, f"{condition_name}_indices.json")
    with open(meta_path, "w") as f:
        json.dump(
            {
                "condition": condition_name,
                "reference_condition": reference_condition,
                "matched_n": len(indices),
                "pool_size": len(pool),
                "sample_indices": indices,
                "random_seed": cfg.seed + seed_offset,
            },
            f,
            indent=2,
        )
    return run_condition(
        condition_name,
        train_langs=LANGUAGES,
        eval_langs=eval_langs,
        cluster_map=None,
        cfg=cfg,
        device=device,
        raw_train_ds=subset,
        extra_meta={
            "matched_to": reference_condition,
            "matched_n": len(indices),
            "pool_size": len(pool),
        },
    )


def build_clustering_meta(
    ling_map: Dict[str, int],
    emb_meta: Dict,
    cfg: RunConfig,
    budget_meta: Optional[Dict] = None,
) -> Dict:
    meta = {
        "linguistic": {
            "method": "head_parameter",
            "head_final": sorted(HEAD_FINAL),
            "head_initial": sorted(HEAD_INITIAL),
            "n_clusters": 2,
            "cluster_map": ling_map,
        },
        "embedding": emb_meta,
        "language_pool": _POOL_META,
        "config": {
            "languages": LANGUAGES,
            "hypothesis_controls": _POOL_META["hypothesis_controls"],
            "pool_name": _POOL_META["pool_name"],
            "low_resource_langs": LOW_RESOURCE_LANGS,
            "low_resource_threshold": LOW_RESOURCE_THRESHOLD,
            "target_lang": TARGET_LANG,
            "seed": cfg.seed,
            "max_epochs": cfg.max_epochs,
            "max_train_per_lang": cfg.max_train_per_lang,
            "max_embed_samples_per_lang": cfg.max_embed_samples_per_lang,
            "max_eval_samples_per_lang": cfg.max_eval_samples_per_lang,
            "n_clusters": cfg.n_clusters,
            "quick": cfg.quick,
            "upsample_to": cfg.upsample_to,
            "upsample_target_n": get_upsample_target_n(cfg),
            "downsample_to": cfg.downsample_to,
            "budget_n_ref": cfg.budget_n_ref,
            "budget_n_ref_embedding": cfg.budget_n_ref_embedding,
            "budget_n_ref_linguistic": cfg.budget_n_ref_linguistic,
        },
    }
    if budget_meta:
        meta["budget"] = budget_meta
    return meta


def aggregate_final_info(all_runs: Dict[str, Dict], n_seeds: int) -> Dict:
    """Aggregate per-seed results into AI Scientist-compatible final_info.json."""
    conditions = CONDITIONS
    final_info: Dict = {}
    for cond in conditions:
        metric_keys = set()
        for i in range(n_seeds):
            if cond not in all_runs[f"seed_{i}"]:
                continue
            metric_keys.update(all_runs[f"seed_{i}"][cond]["means"].keys())
        if not metric_keys:
            continue
        means = {}
        stderrs = {}
        for key in sorted(metric_keys):
            vals = [
                all_runs[f"seed_{i}"][cond]["means"][key]
                for i in range(n_seeds)
                if cond in all_runs[f"seed_{i}"]
            ]
            means[key] = float(np.mean(vals))
            stderrs[key] = (
                float(np.std(vals) / np.sqrt(len(vals))) if len(vals) > 1 else 0.0
            )
        final_info[cond] = {"means": means, "stderrs": stderrs}
    return final_info


def run_experiment(cfg: RunConfig) -> Dict:
    os.makedirs(cfg.out_dir, exist_ok=True)
    set_seed(cfg.seed)
    device = get_device()

    ling_map = cluster_linguistic(LANGUAGES)
    emb_map, emb_meta = cluster_embedding(LANGUAGES, cfg, device)

    eval_langs = LANGUAGES
    emb_train_langs = post_cluster_train_langs(
        TARGET_LANG,
        langs_in_cluster(TARGET_LANG, emb_map),
        emb_map,
        cfg,
        source="embedding",
    )
    emb_n_samples = count_train_samples(emb_train_langs, cfg)
    ling_train_langs = post_cluster_train_langs(
        TARGET_LANG,
        langs_in_cluster(TARGET_LANG, ling_map),
        ling_map,
        cfg,
        source="linguistic",
    )

    budget_meta = resolve_training_budget(
        cfg, emb_map, ling_map, emb_train_langs, ling_train_langs
    )
    clustering_meta = build_clustering_meta(ling_map, emb_meta, cfg, budget_meta)

    with open(os.path.join(cfg.out_dir, "cluster_linguistic.json"), "w") as f:
        json.dump(ling_map, f, indent=2)
    with open(os.path.join(cfg.out_dir, "cluster_embedding.json"), "w") as f:
        json.dump(emb_map, f, indent=2)
    with open(os.path.join(cfg.out_dir, "clustering_meta.json"), "w") as f:
        json.dump(clustering_meta, f, indent=2)

    matched_emb_n = cfg.budget_n_ref_embedding or emb_n_samples
    matched_ling_n = cfg.budget_n_ref_linguistic or count_train_samples(
        ling_train_langs, cfg
    )

    def _skipped(name: str) -> bool:
        return bool(cfg.skip_conditions and name in cfg.skip_conditions)

    results: Dict = {}
    if not _skipped("linguistic_clustering"):
        results["linguistic_clustering"] = run_condition(
            "linguistic_clustering",
            train_langs=ling_train_langs,
            eval_langs=eval_langs,
            cluster_map=ling_map,
            cfg=cfg,
            device=device,
        )
    if not _skipped("embedding_clustering"):
        results["embedding_clustering"] = run_condition(
            "embedding_clustering",
            train_langs=emb_train_langs,
            eval_langs=eval_langs,
            cluster_map=emb_map,
            cfg=cfg,
            device=device,
        )
    if not _skipped("per_language"):
        results["per_language"] = run_condition(
            "per_language",
            train_langs=[TARGET_LANG],
            eval_langs=[TARGET_LANG],
            cluster_map=None,
            cfg=cfg,
            device=device,
        )
    if not _skipped("all_mixed"):
        results["all_mixed"] = run_condition(
            "all_mixed",
            train_langs=LANGUAGES,
            eval_langs=eval_langs,
            cluster_map=None,
            cfg=cfg,
            device=device,
        )
    if not _skipped("matched_random_embedding"):
        results["matched_random_embedding"] = run_matched_random_condition(
            "matched_random_embedding",
            n_samples=matched_emb_n,
            eval_langs=eval_langs,
            cfg=cfg,
            device=device,
            reference_condition="embedding_clustering",
        )
    if not _skipped("matched_random_linguistic"):
        results["matched_random_linguistic"] = run_matched_random_condition(
            "matched_random_linguistic",
            n_samples=matched_ling_n,
            eval_langs=eval_langs,
            cfg=cfg,
            device=device,
            reference_condition="linguistic_clustering",
        )
    if cfg.skip_conditions:
        print(f"[skip] conditions not run: {sorted(cfg.skip_conditions)}")

    results["metadata"] = {
            "languages": LANGUAGES,
            "language_pool": _POOL_META,
            "target_lang": TARGET_LANG,
            "primary_metric": PRIMARY_METRIC_KEY,
            "low_resource_metric": LOW_RESOURCE_METRIC_KEY,
            "model": MODEL_NAME,
            "seed": cfg.seed,
            "max_epochs": cfg.max_epochs,
            "batch_size": cfg.batch_size,
            "max_train_per_lang": cfg.max_train_per_lang,
            "quick": cfg.quick,
            "upsample_to": cfg.upsample_to,
            "upsample_target_n": get_upsample_target_n(cfg),
            "downsample_to": cfg.downsample_to,
            "budget": budget_meta,
            "embedding_cluster_n_samples": emb_n_samples,
            "linguistic_cluster_n_samples": count_train_samples(ling_train_langs, cfg),
            "matched_random_embedding_n_samples": matched_emb_n,
            "matched_random_linguistic_n_samples": matched_ling_n,
            "all_mixed_n_samples": budget_meta.get("all_mixed_n_samples"),
            "skipped_conditions": sorted(cfg.skip_conditions or []),
    }
    return results


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="asian_ner minimal PoC experiment")
    p.add_argument("--out_dir", type=str, default="run_0")
    p.add_argument("--seed", type=int, default=1)
    p.add_argument("--max_epochs", type=int, default=2)
    p.add_argument("--batch_size", type=int, default=16)
    p.add_argument("--learning_rate", type=float, default=5e-5)
    p.add_argument("--max_length", type=int, default=128)
    p.add_argument("--max_train_per_lang", type=int, default=0,
                   help="Per-language train cap (0 = full WikiAnn, no cap)")
    p.add_argument("--max_embed_samples_per_lang", type=int, default=200)
    p.add_argument(
        "--num_seeds",
        type=int,
        default=None,
        help="Number of seeds to run (default: 1 if --quick else 3)",
    )
    p.add_argument(
        "--upsample_to",
        type=str,
        default=None,
        help='Legacy bootstrap-upsampling reference (e.g. "all_mixed"). '
        "Mutually exclusive with --downsample_to target_cluster.",
    )
    p.add_argument(
        "--downsample_to",
        type=str,
        default="target_cluster",
        help='Budget mode. "target_cluster" (default): dual matched controls at each '
        "cluster n, all_mixed full pool. "
        '"largest_cluster": legacy downsample all/matched to max cluster. "none": no override.',
    )
    p.add_argument(
        "--skip_conditions",
        type=str,
        default="all_mixed",
        help="Comma-separated conditions to skip, e.g. 'all_mixed' or 'all_mixed,per_language'",
    )
    p.add_argument("--quick", action="store_true", help="Smoke test (1 epoch, tiny data)")
    args = p.parse_args()
    skip_set = {x.strip() for x in args.skip_conditions.split(",") if x.strip()}
    unknown = skip_set - set(CONDITIONS)
    if unknown:
        raise ValueError(f"Unknown skip_conditions: {sorted(unknown)}; valid: {CONDITIONS}")
    args.skip_conditions_set = skip_set or None
    return args


if __name__ == "__main__":
    args = parse_args()
    cfg = build_config(args)

    num_seeds = args.num_seeds if args.num_seeds is not None else 1
    seeds = [cfg.seed + i for i in range(num_seeds)]
    all_runs: Dict[str, Dict] = {}

    for i, seed in enumerate(seeds):
        run_dir = args.out_dir if len(seeds) == 1 else os.path.join(args.out_dir, f"seed_{i}")
        run_cfg = RunConfig(
            out_dir=run_dir,
            seed=seed,
            max_epochs=cfg.max_epochs,
            batch_size=cfg.batch_size,
            learning_rate=cfg.learning_rate,
            max_length=cfg.max_length,
            max_train_per_lang=cfg.max_train_per_lang,
            max_embed_samples_per_lang=cfg.max_embed_samples_per_lang,
            max_eval_samples_per_lang=cfg.max_eval_samples_per_lang,
            lang_id_epochs=cfg.lang_id_epochs,
            n_clusters=cfg.n_clusters,
            quick=cfg.quick,
            upsample_to=cfg.upsample_to,
            downsample_to=cfg.downsample_to,
            skip_conditions=cfg.skip_conditions,
        )
        print(
            f"=== Running seed {seed} ({i + 1}/{num_seeds}) -> {run_dir} "
            f"[device={get_device()}] ==="
        )
        result = run_experiment(run_cfg)
        with open(os.path.join(run_dir, "final_info.json"), "w") as f:
            json.dump(result, f, indent=2)
        all_runs[f"seed_{i}"] = result

    final_info = aggregate_final_info(all_runs, len(seeds))
    with open(os.path.join(args.out_dir, "final_info.json"), "w") as f:
        json.dump(final_info, f, indent=2)

    with open(os.path.join(args.out_dir, "detailed_results.json"), "w") as f:
        json.dump(all_runs, f, indent=2)

    # Promote clustering artifacts from the first seed to the top-level out_dir.
    first_seed_dir = args.out_dir if len(seeds) == 1 else os.path.join(args.out_dir, "seed_0")
    for fname in (
        "clustering_meta.json",
        "cluster_linguistic.json",
        "cluster_embedding.json",
    ):
        src = os.path.join(first_seed_dir, fname)
        if os.path.exists(src):
            with open(src, "r") as f:
                data = json.load(f)
            with open(os.path.join(args.out_dir, fname), "w") as f:
                json.dump(data, f, indent=2)

    print("Done. Wrote final_info.json, detailed_results.json, clustering_meta.json")
